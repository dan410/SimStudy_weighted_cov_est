#!/bin/csh

#SBATCH -A spyglass
#SBATCH -t 60
#SBATCH -N 2
#SBATCH -n 64
#SBATCH -p short
#SBATCH -o /pic/scratch/fort002/CovEst_tmp_23030/slurmLaunch.out
#SBATCH -e /pic/scratch/fort002/CovEst_tmp_23030/slurmLaunch.err

#SBATCH --mail-type=END
#SBATCH --mail-user=daniel.fortin@pnnl.gov

date "+DateTime %Y-%m-%d %T"
source /etc/profile.d/modules.csh
module purge
module load gcc/4.6.0
module load mvapich2/1.7
unlimit

echo
echo "loaded modules"
echo
module list >& _modules.lis_
cat _modules.lis_
/bin/rm -f _modules.lis_
echo
echo "Limits"
echo
limit
echo
echo "Environmental Variables"
echo
printenv
echo
echo "ldd output"
echo
ldd /pic/scratch/fort002/CovEst_tmp_23030/launch.o

echo "Launch the R jobs"
srun --mpi=none /pic/scratch/fort002/CovEst_tmp_23030/launch.o
echo "srun is complete"

date "+DateTime %Y-%m-%d %T"
echo "Job completion"
